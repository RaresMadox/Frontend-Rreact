import React from "react";

function Markets() {
  return <div>Markets</div>;
}

export default Markets;
